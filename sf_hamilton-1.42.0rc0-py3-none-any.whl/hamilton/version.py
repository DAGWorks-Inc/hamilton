VERSION = (1, 42, 0, "rc0")

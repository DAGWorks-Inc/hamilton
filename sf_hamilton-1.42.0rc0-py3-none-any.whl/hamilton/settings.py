ENABLE_POWER_USER_MODE = "hamilton.enable_power_user_mode"

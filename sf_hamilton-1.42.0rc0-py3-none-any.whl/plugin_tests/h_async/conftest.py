from hamilton import telemetry

# disable telemetry for all tests!
telemetry.disable_telemetry()

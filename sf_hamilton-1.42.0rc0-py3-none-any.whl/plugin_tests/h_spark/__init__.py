__author__ = "Stefan Krawczyk <stefank@cs.stanford.edu>"

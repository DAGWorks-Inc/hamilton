def key_overwrite_ignoring_input() -> str:
    return "user_specified_value"


def key_to_overwrite() -> str:
    return "user_specified_value"

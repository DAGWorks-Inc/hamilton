def some_key() -> str:
    return "some_value"

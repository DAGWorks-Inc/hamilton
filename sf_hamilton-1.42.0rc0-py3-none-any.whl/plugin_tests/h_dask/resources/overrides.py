def b(a: int) -> int:
    return a + 1


def c(b: int) -> int:
    return b + 1


def d(c: int) -> int:
    return c + 1

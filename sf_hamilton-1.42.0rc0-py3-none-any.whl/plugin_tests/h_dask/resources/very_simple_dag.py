def b(a: int) -> int:
    return a

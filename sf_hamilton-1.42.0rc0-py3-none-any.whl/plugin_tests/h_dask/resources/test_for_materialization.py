def json_to_save_1() -> dict:
    return {
        "key1": "value1",
        "key2": "value2",
    }


def json_to_save_2() -> dict:
    return {
        "key3": "value3",
        "key4": "value4",
    }

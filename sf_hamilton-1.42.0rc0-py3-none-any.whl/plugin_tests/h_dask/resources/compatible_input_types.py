from typing import Union


def b(a: Union[int, str]) -> int:
    return a


def c(a: str) -> str:
    return a


def d(a: str) -> str:
    return a
